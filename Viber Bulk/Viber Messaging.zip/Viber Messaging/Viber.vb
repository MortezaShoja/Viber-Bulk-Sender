﻿
Public Class Viber

    Private AutoStart As Boolean = False

    Private Sub Viber_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Application.Exit()
    End Sub

    Private Sub Viber_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Me.KeyPress
        If e.KeyChar = Chr(27) Then
            Me.Timer1.Enabled = False
        End If
    End Sub

    Private Sub Viber_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Process.Start("C:\Viber\Viber.4.2.2.6\viber.exe")
        'Dim FL As New FileLocation
        'AppLocation.OpenApplication()
        'FL.OpenApplication()
        If Not System.IO.Directory.Exists("C:\ViberMessaging") Then
            System.IO.Directory.CreateDirectory("C:\ViberMessaging")
            System.IO.Directory.CreateDirectory("C:\ViberMessaging\Images")
            System.IO.Directory.CreateDirectory("C:\ViberMessaging\System")

            Dim SW As New System.IO.StreamWriter("C:\ViberMessaging\System\Numbers.sys")
            SW.WriteLine("1000000")
            SW.WriteLine("1000349")
            SW.WriteLine(Now.AddMinutes(-30).ToString)
            SW.Flush()
            SW.Close()
        End If

        Dim SR As New System.IO.StreamReader("C:\ViberMessaging\System\Numbers.sys")
        Me.txtFromNumber.Text = SR.ReadLine
        Me.txtToNumber.Text = SR.ReadLine
        Me.lblLastSentTime.Text = SR.ReadLine
        SR.Close()

    End Sub

    Private Sub MoveCursor(ByVal X As Integer, ByVal Y As Integer)
        ' Set the Current cursor, move the cursor's Position, 
        ' and set its clipping rectangle to the form.  

        Me.Cursor = New Cursor(Cursor.Current.Handle)
        Cursor.Position = New Point(X, Y)
        Cursor.Clip = New Rectangle(Me.Location, Me.Size)
    End Sub

    Private Sub btnStart_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStart.Click

        SendingVSMS()

    End Sub

    Private Sub SendingVSMS()
        If Me.txtMessage.Text <> "" Then
            If Now > (CType(Me.lblLastSentTime.Text, Date).AddMinutes(30)) Then

                Dim SW As New System.IO.StreamWriter("C:\ViberMessaging\System\Numbers.sys")
                SW.WriteLine(Integer.Parse(Me.txtToNumber.Text) + 1)
                SW.WriteLine(Integer.Parse(Me.txtToNumber.Text) + 350)
                SW.WriteLine(Now.ToString)
                SW.Flush()
                SW.Close()

                '----------------------------------------------

                Dim TypeOfLanguage = New System.Globalization.CultureInfo("en") ' or "fa-IR" for Farsi(Iran) 
                InputLanguage.CurrentInputLanguage = InputLanguage.FromCulture(TypeOfLanguage)
                Threading.Thread.Sleep(2000)
                GenerateNumber()


                Me.txtToNumber.Text += 349
                Me.txtFromNumber.Text += 349
                MessageBox.Show("ارسال پیام ها با موفقیت به پایان رسید", "ارسال پیام", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.RightAlign, False)
                If AutoStart = True Then
                    Threading.Thread.Sleep(180000)
                    SendingVSMS()
                End If
            Else
                MessageBox.Show("امکان ارسال میسر نمی باشد" & vbCrLf & "میبایست از آخرین ارسال 30 دقیقه گذشته باشد" & vbCrLf & Me.lblLastSentTime.Text & " آخرین زمان ارسال شما", "خطا در ارسال پیام", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, MessageBoxOptions.RightAlign)
            End If
        Else
            MessageBox.Show("لطفا متن پیام را بنویسید", "ارسال پیام", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.RightAlign, False)
        End If
    End Sub
    Private Sub GenerateNumber()
        Dim IC As New InternetChecker
        Dim I As Integer = (Integer.Parse(Me.txtToNumber.Text) - Integer.Parse(Me.txtFromNumber.Text))

        Dim StartN As Integer = Integer.Parse(Me.txtFromNumber.Text)
        Try
            For J As Integer = 0 To (Integer.Parse(txtToNumber.Text) - Integer.Parse(Me.txtFromNumber.Text))
                'If J > 1 And (J Mod 50) = 0 Then
                '    Threading.Thread.Sleep(300000)
                'End If
                SendMessage(Me.txtPishShomare.Text & (Double.Parse(Me.txtFromNumber.Text) + J).ToString)
                Me.ProgressBar1.Value = J
            Next
        Catch ex As Exception
            MessageBox.Show("Mission Error" & vbCrLf & ex.Message.ToString, "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, MessageBoxOptions.RightAlign)
        End Try

    End Sub

    Private Sub SendMessage(ByVal Number As String)

        Threading.Thread.Sleep(1000)
        SendKeys.Send("{ESC}")

        MoveCursor(145, 320) ' Move to Call Icon
        Win32.mouse_event(Win32.MOUSEEVENTF_LEFTDOWN, 50, 50, 50, 50)
        Threading.Thread.Sleep(100)
        Win32.mouse_event(Win32.MOUSEEVENTF_LEFTUP, 50, 50, 50, 50)
        Threading.Thread.Sleep(100)

        MoveCursor(280, 220) ' Move to Phone Number Position
        My.Computer.Clipboard.SetText(Number)
        Threading.Thread.Sleep(100)

        Win32.mouse_event(Win32.MOUSEEVENTF_LEFTDOWN, 50, 50, 50, 50)
        Win32.mouse_event(Win32.MOUSEEVENTF_LEFTUP, 50, 50, 50, 50)
        Threading.Thread.Sleep(100)
        Win32.mouse_event(Win32.MOUSEEVENTF_LEFTDOWN, 50, 50, 50, 50)
        Win32.mouse_event(Win32.MOUSEEVENTF_LEFTUP, 50, 50, 50, 50)

        Threading.Thread.Sleep(100)
        SendKeys.Send("^(v)")
        Threading.Thread.Sleep(100)

        '--------------- Send Message ----------------
        MoveCursor(335, 445) ' Move to Text Message Icon In Call Menu
        Win32.mouse_event(Win32.MOUSEEVENTF_LEFTDOWN, 50, 50, 50, 50)
        Threading.Thread.Sleep(100)
        Win32.mouse_event(Win32.MOUSEEVENTF_LEFTUP, 50, 50, 50, 50)

        MoveCursor(650, 665) ' Move to Message Text Location
        Threading.Thread.Sleep(2000)
        My.Computer.Clipboard.SetText(Me.txtMessage.Text)

        Win32.mouse_event(Win32.MOUSEEVENTF_LEFTDOWN, 50, 50, 50, 50)
        Threading.Thread.Sleep(100)
        Win32.mouse_event(Win32.MOUSEEVENTF_LEFTUP, 50, 50, 50, 50)
        '-------------------- Sending ------------------------------

        Threading.Thread.Sleep(200)
        SendKeys.Send("^(v)")
        Threading.Thread.Sleep(200)
        SendKeys.Send("{ENTER}")
        Threading.Thread.Sleep(500)

        '------------ Selecting Images -------------

        Dim di As New IO.DirectoryInfo("C:\ViberMessaging\Images")
        Dim diar1 As IO.FileInfo() = di.GetFiles()

        If diar1.Length > 0 Then
            MoveCursor(460, 665) ' Move to Send Photo Icon
            Threading.Thread.Sleep(100)

            For I = 0 To diar1.Length - 1

                SendKeys.Send("{ESC}")
                My.Computer.Clipboard.SetText("C:\ViberMessaging\Images\" & diar1(I).ToString)

                Win32.mouse_event(Win32.MOUSEEVENTF_LEFTDOWN, 50, 50, 50, 50)
                Threading.Thread.Sleep(100)
                Win32.mouse_event(Win32.MOUSEEVENTF_LEFTUP, 50, 50, 50, 50)

                Threading.Thread.Sleep(3000)
                SendKeys.Send("^(v)")
                Threading.Thread.Sleep(100)
                SendKeys.Send("{ENTER}")
                Threading.Thread.Sleep(3000)

            Next
        End If

        MoveCursor(145, 500) ' Move to Left Free Balck Side
        Win32.mouse_event(Win32.MOUSEEVENTF_LEFTDOWN, 50, 50, 50, 50)
        Threading.Thread.Sleep(100)
        Win32.mouse_event(Win32.MOUSEEVENTF_LEFTUP, 50, 50, 50, 50)

    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Dim MousePosition As Point
        MousePosition = Cursor.Position
        Me.Label1.Text = MousePosition.X.ToString & vbCrLf & MousePosition.Y.ToString
    End Sub

    Private Sub txtPishShomare_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtPishShomare.TextChanged
        Me.txtPishShomare2.Text = Me.txtPishShomare.Text
    End Sub

    Private Sub txtFromNumber_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtFromNumber.TextChanged
        Try
            Me.txtToNumber.Text = (Integer.Parse(Me.txtFromNumber.Text) + 349).ToString
        Catch ex As Exception
            Me.txtToNumber.Text = "0"
        End Try

    End Sub

    Private Sub btnOpenImagePlace_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOpenImagePlace.Click
        Process.Start("explorer.exe", "C:\ViberMessaging\Images")
    End Sub

    Private Sub btnAutosending_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAutosending.Click
        If AutoStart = False Then
            AutoStart = True
            MessageBox.Show("آغاز ارسال خودکار", "ارسال پیام", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.RightAlign, False)
            SendingVSMS()
        Else
            AutoStart = False
            MessageBox.Show("پایان ارسال خودکار", "ارسال پیام", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.RightAlign, False)
        End If
    End Sub


    Private Sub txtToNumber_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtToNumber.TextChanged
        Try
            If Me.txtToNumber.Text - Me.txtFromNumber.Text > 351 Then
                MessageBox.Show("امکان ارسال بیش از 350 پیام در هر با ارسال ممکن نیست", "ارسال پیام", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, MessageBoxOptions.RightAlign, False)
                Me.txtToNumber.Text = (Integer.Parse(Me.txtFromNumber.Text) + 349).ToString
            End If
        Catch ex As Exception
            Me.txtToNumber.Text = "0"
        End Try

    End Sub
End Class