﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Viber
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Viber))
        Me.btnStart = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.txtMessage = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.ProgressBar1 = New System.Windows.Forms.ProgressBar()
        Me.txtPishShomare2 = New System.Windows.Forms.TextBox()
        Me.txtPishShomare = New System.Windows.Forms.TextBox()
        Me.txtToNumber = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtFromNumber = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.lblLastSentTime = New System.Windows.Forms.Label()
        Me.btnOpenImagePlace = New System.Windows.Forms.Button()
        Me.btnAutosending = New System.Windows.Forms.Button()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnStart
        '
        Me.btnStart.Location = New System.Drawing.Point(864, 489)
        Me.btnStart.Name = "btnStart"
        Me.btnStart.Size = New System.Drawing.Size(216, 23)
        Me.btnStart.TabIndex = 1
        Me.btnStart.Text = "Start Manual Sending"
        Me.btnStart.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(864, 320)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(217, 13)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "----------------------------------------------------------------------"
        '
        'Timer1
        '
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.PictureBox1.Location = New System.Drawing.Point(12, 12)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(846, 562)
        Me.PictureBox1.TabIndex = 3
        Me.PictureBox1.TabStop = False
        '
        'txtMessage
        '
        Me.txtMessage.Location = New System.Drawing.Point(864, 39)
        Me.txtMessage.Multiline = True
        Me.txtMessage.Name = "txtMessage"
        Me.txtMessage.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.txtMessage.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtMessage.Size = New System.Drawing.Size(216, 278)
        Me.txtMessage.TabIndex = 4
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(1019, 12)
        Me.Label2.Name = "Label2"
        Me.Label2.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.Label2.Size = New System.Drawing.Size(65, 20)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "متن پیام :"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ProgressBar1
        '
        Me.ProgressBar1.Location = New System.Drawing.Point(864, 460)
        Me.ProgressBar1.Maximum = 500
        Me.ProgressBar1.Name = "ProgressBar1"
        Me.ProgressBar1.Size = New System.Drawing.Size(216, 23)
        Me.ProgressBar1.TabIndex = 6
        '
        'txtPishShomare2
        '
        Me.txtPishShomare2.Location = New System.Drawing.Point(864, 434)
        Me.txtPishShomare2.Name = "txtPishShomare2"
        Me.txtPishShomare2.ReadOnly = True
        Me.txtPishShomare2.Size = New System.Drawing.Size(50, 20)
        Me.txtPishShomare2.TabIndex = 14
        Me.txtPishShomare2.Text = "0912"
        '
        'txtPishShomare
        '
        Me.txtPishShomare.Location = New System.Drawing.Point(864, 408)
        Me.txtPishShomare.Name = "txtPishShomare"
        Me.txtPishShomare.Size = New System.Drawing.Size(50, 20)
        Me.txtPishShomare.TabIndex = 13
        Me.txtPishShomare.Text = "0912"
        '
        'txtToNumber
        '
        Me.txtToNumber.Location = New System.Drawing.Point(920, 434)
        Me.txtToNumber.Name = "txtToNumber"
        Me.txtToNumber.Size = New System.Drawing.Size(82, 20)
        Me.txtToNumber.TabIndex = 12
        Me.txtToNumber.Text = "0"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(1008, 437)
        Me.Label3.Name = "Label3"
        Me.Label3.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.Label3.Size = New System.Drawing.Size(66, 13)
        Me.Label3.TabIndex = 11
        Me.Label3.Text = "To Number :"
        '
        'txtFromNumber
        '
        Me.txtFromNumber.Location = New System.Drawing.Point(920, 408)
        Me.txtFromNumber.Name = "txtFromNumber"
        Me.txtFromNumber.Size = New System.Drawing.Size(82, 20)
        Me.txtFromNumber.TabIndex = 10
        Me.txtFromNumber.Text = "0"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(1009, 411)
        Me.Label4.Name = "Label4"
        Me.Label4.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.Label4.Size = New System.Drawing.Size(76, 13)
        Me.Label4.TabIndex = 9
        Me.Label4.Text = "From Number :"
        '
        'lblLastSentTime
        '
        Me.lblLastSentTime.AutoSize = True
        Me.lblLastSentTime.Location = New System.Drawing.Point(864, 17)
        Me.lblLastSentTime.Name = "lblLastSentTime"
        Me.lblLastSentTime.Size = New System.Drawing.Size(89, 13)
        Me.lblLastSentTime.TabIndex = 15
        Me.lblLastSentTime.Text = "آخرین زمان ارسال"
        Me.lblLastSentTime.Visible = False
        '
        'btnOpenImagePlace
        '
        Me.btnOpenImagePlace.Location = New System.Drawing.Point(867, 379)
        Me.btnOpenImagePlace.Name = "btnOpenImagePlace"
        Me.btnOpenImagePlace.Size = New System.Drawing.Size(216, 23)
        Me.btnOpenImagePlace.TabIndex = 16
        Me.btnOpenImagePlace.Text = "Open Pictures"
        Me.btnOpenImagePlace.UseVisualStyleBackColor = True
        '
        'btnAutosending
        '
        Me.btnAutosending.Location = New System.Drawing.Point(864, 518)
        Me.btnAutosending.Name = "btnAutosending"
        Me.btnAutosending.Size = New System.Drawing.Size(216, 23)
        Me.btnAutosending.TabIndex = 17
        Me.btnAutosending.Text = "Start Auto Sending"
        Me.btnAutosending.UseVisualStyleBackColor = True
        '
        'Viber
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1092, 586)
        Me.Controls.Add(Me.btnAutosending)
        Me.Controls.Add(Me.btnOpenImagePlace)
        Me.Controls.Add(Me.lblLastSentTime)
        Me.Controls.Add(Me.txtPishShomare2)
        Me.Controls.Add(Me.txtPishShomare)
        Me.Controls.Add(Me.txtToNumber)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtFromNumber)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.ProgressBar1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtMessage)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnStart)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Viber"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Viber"
        Me.TransparencyKey = System.Drawing.SystemColors.ActiveCaption
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnStart As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents txtMessage As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents ProgressBar1 As System.Windows.Forms.ProgressBar
    Friend WithEvents txtPishShomare2 As System.Windows.Forms.TextBox
    Friend WithEvents txtPishShomare As System.Windows.Forms.TextBox
    Friend WithEvents txtToNumber As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtFromNumber As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents lblLastSentTime As System.Windows.Forms.Label
    Friend WithEvents btnOpenImagePlace As System.Windows.Forms.Button
    Friend WithEvents btnAutosending As System.Windows.Forms.Button
End Class
