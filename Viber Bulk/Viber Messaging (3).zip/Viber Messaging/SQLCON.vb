Imports Microsoft.VisualBasic
Imports System.Data.SqlClient

Public Class SQLCON
    Public SqlCon As New System.Data.SqlClient.SqlConnection("Data Source=87.247.179.155,1633;Initial Catalog=Viber20.com;User ID=viber20.com;Password=Viber20.Com")
End Class
