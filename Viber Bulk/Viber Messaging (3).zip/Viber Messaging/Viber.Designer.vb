﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Viber
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Viber))
        Me.lblMouseX = New System.Windows.Forms.Label()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.txtMessage = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.lblLastSentTime = New System.Windows.Forms.Label()
        Me.btnOpenImagePlace = New System.Windows.Forms.Button()
        Me.btnAutosending = New System.Windows.Forms.Button()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.tabBulk = New System.Windows.Forms.TabPage()
        Me.btnStopSending = New System.Windows.Forms.Button()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.txtAreaCode = New System.Windows.Forms.TextBox()
        Me.rbOnlinePhoneBook = New System.Windows.Forms.RadioButton()
        Me.rbOfflinePhoneBook = New System.Windows.Forms.RadioButton()
        Me.rbManualNumbers = New System.Windows.Forms.RadioButton()
        Me.cboOnlinePhonebook = New System.Windows.Forms.ComboBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.cboOfflinePhonebook = New System.Windows.Forms.ComboBox()
        Me.NuManualSendCount = New System.Windows.Forms.NumericUpDown()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.tabPhoneBook = New System.Windows.Forms.TabPage()
        Me.lstPhone = New System.Windows.Forms.ListBox()
        Me.btnDelPhonebook = New System.Windows.Forms.Button()
        Me.btnEditPhonebook = New System.Windows.Forms.Button()
        Me.btnAddPhonebook = New System.Windows.Forms.Button()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtPhonebookName = New System.Windows.Forms.TextBox()
        Me.btnDel = New System.Windows.Forms.Button()
        Me.btnEdit = New System.Windows.Forms.Button()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtPhoneNumber = New System.Windows.Forms.TextBox()
        Me.cboPhoneBook = New System.Windows.Forms.ComboBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.tabSetting = New System.Windows.Forms.TabPage()
        Me.btnViberFileLocation = New System.Windows.Forms.Button()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.btnSaveLocations = New System.Windows.Forms.Button()
        Me.GroupBox10 = New System.Windows.Forms.GroupBox()
        Me.NuFreePlaceY = New System.Windows.Forms.NumericUpDown()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.NuFreePlaceX = New System.Windows.Forms.NumericUpDown()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.GroupBox9 = New System.Windows.Forms.GroupBox()
        Me.NuSendPhotoIconY = New System.Windows.Forms.NumericUpDown()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.NuSendPhotoIconX = New System.Windows.Forms.NumericUpDown()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.NuMessageLocationY = New System.Windows.Forms.NumericUpDown()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.NuMessageLocationX = New System.Windows.Forms.NumericUpDown()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.NuPhoneNumberBoxY = New System.Windows.Forms.NumericUpDown()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.NuPhoneNumberBoxX = New System.Windows.Forms.NumericUpDown()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.GroupBox8 = New System.Windows.Forms.GroupBox()
        Me.NuSendTextMessageIconY = New System.Windows.Forms.NumericUpDown()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.NuSendTextMessageIconX = New System.Windows.Forms.NumericUpDown()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.NuCallIconY = New System.Windows.Forms.NumericUpDown()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.NuCallIconX = New System.Windows.Forms.NumericUpDown()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.lblMouseY = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.nuSleepTime = New System.Windows.Forms.NumericUpDown()
        Me.tabLicence = New System.Windows.Forms.TabPage()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.GroupBox11 = New System.Windows.Forms.GroupBox()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.lblLicenceExpireDate = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.lblLicenceStartDate = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.lblLicencetype = New System.Windows.Forms.Label()
        Me.lblLicenceowner = New System.Windows.Forms.Label()
        Me.DetailsLayoutPanel = New System.Windows.Forms.TableLayoutPanel()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Version = New System.Windows.Forms.Label()
        Me.Copyright = New System.Windows.Forms.Label()
        Me.ApplicationTitle = New System.Windows.Forms.Label()
        Me.TimerImageCount = New System.Windows.Forms.Timer(Me.components)
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.txtPishShomare = New System.Windows.Forms.TextBox()
        Me.txtNumber = New System.Windows.Forms.TextBox()
        Me.TabControl1.SuspendLayout()
        Me.tabBulk.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.NuManualSendCount, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tabPhoneBook.SuspendLayout()
        Me.tabSetting.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox10.SuspendLayout()
        CType(Me.NuFreePlaceY, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NuFreePlaceX, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox9.SuspendLayout()
        CType(Me.NuSendPhotoIconY, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NuSendPhotoIconX, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox7.SuspendLayout()
        CType(Me.NuMessageLocationY, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NuMessageLocationX, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox6.SuspendLayout()
        CType(Me.NuPhoneNumberBoxY, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NuPhoneNumberBoxX, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox8.SuspendLayout()
        CType(Me.NuSendTextMessageIconY, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NuSendTextMessageIconX, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox5.SuspendLayout()
        CType(Me.NuCallIconY, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NuCallIconX, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox3.SuspendLayout()
        CType(Me.nuSleepTime, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tabLicence.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox11.SuspendLayout()
        Me.DetailsLayoutPanel.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblMouseX
        '
        Me.lblMouseX.AutoSize = True
        Me.lblMouseX.Location = New System.Drawing.Point(80, 22)
        Me.lblMouseX.Name = "lblMouseX"
        Me.lblMouseX.Size = New System.Drawing.Size(19, 13)
        Me.lblMouseX.TabIndex = 2
        Me.lblMouseX.Text = "----"
        '
        'Timer1
        '
        '
        'txtMessage
        '
        Me.txtMessage.Location = New System.Drawing.Point(6, 19)
        Me.txtMessage.Multiline = True
        Me.txtMessage.Name = "txtMessage"
        Me.txtMessage.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtMessage.Size = New System.Drawing.Size(220, 261)
        Me.txtMessage.TabIndex = 4
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(30, 34)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(49, 13)
        Me.Label4.TabIndex = 9
        Me.Label4.Text = "Numbers"
        '
        'lblLastSentTime
        '
        Me.lblLastSentTime.AutoSize = True
        Me.lblLastSentTime.Location = New System.Drawing.Point(109, 52)
        Me.lblLastSentTime.Name = "lblLastSentTime"
        Me.lblLastSentTime.Size = New System.Drawing.Size(16, 13)
        Me.lblLastSentTime.TabIndex = 15
        Me.lblLastSentTime.Text = "---"
        '
        'btnOpenImagePlace
        '
        Me.btnOpenImagePlace.Location = New System.Drawing.Point(9, 421)
        Me.btnOpenImagePlace.Name = "btnOpenImagePlace"
        Me.btnOpenImagePlace.Size = New System.Drawing.Size(235, 23)
        Me.btnOpenImagePlace.TabIndex = 16
        Me.btnOpenImagePlace.Text = "Open Pictures"
        Me.btnOpenImagePlace.UseVisualStyleBackColor = True
        '
        'btnAutosending
        '
        Me.btnAutosending.Location = New System.Drawing.Point(9, 450)
        Me.btnAutosending.Name = "btnAutosending"
        Me.btnAutosending.Size = New System.Drawing.Size(106, 23)
        Me.btnAutosending.TabIndex = 17
        Me.btnAutosending.Text = "Start Sending"
        Me.btnAutosending.UseVisualStyleBackColor = True
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.tabBulk)
        Me.TabControl1.Controls.Add(Me.tabPhoneBook)
        Me.TabControl1.Controls.Add(Me.tabSetting)
        Me.TabControl1.Controls.Add(Me.tabLicence)
        Me.TabControl1.Location = New System.Drawing.Point(12, 12)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.Padding = New System.Drawing.Point(0, 0)
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(261, 506)
        Me.TabControl1.TabIndex = 18
        '
        'tabBulk
        '
        Me.tabBulk.BackColor = System.Drawing.Color.MediumPurple
        Me.tabBulk.Controls.Add(Me.btnOpenImagePlace)
        Me.tabBulk.Controls.Add(Me.btnStopSending)
        Me.tabBulk.Controls.Add(Me.GroupBox2)
        Me.tabBulk.Controls.Add(Me.GroupBox1)
        Me.tabBulk.Controls.Add(Me.btnAutosending)
        Me.tabBulk.Location = New System.Drawing.Point(4, 22)
        Me.tabBulk.Name = "tabBulk"
        Me.tabBulk.Padding = New System.Windows.Forms.Padding(3)
        Me.tabBulk.Size = New System.Drawing.Size(253, 480)
        Me.tabBulk.TabIndex = 0
        Me.tabBulk.Text = "Send"
        '
        'btnStopSending
        '
        Me.btnStopSending.Location = New System.Drawing.Point(138, 450)
        Me.btnStopSending.Name = "btnStopSending"
        Me.btnStopSending.Size = New System.Drawing.Size(106, 23)
        Me.btnStopSending.TabIndex = 25
        Me.btnStopSending.Text = "Stop"
        Me.btnStopSending.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.txtMessage)
        Me.GroupBox2.Location = New System.Drawing.Point(9, 153)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(235, 262)
        Me.GroupBox2.TabIndex = 24
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Message Text"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.txtNumber)
        Me.GroupBox1.Controls.Add(Me.txtPishShomare)
        Me.GroupBox1.Controls.Add(Me.txtAreaCode)
        Me.GroupBox1.Controls.Add(Me.rbOnlinePhoneBook)
        Me.GroupBox1.Controls.Add(Me.rbOfflinePhoneBook)
        Me.GroupBox1.Controls.Add(Me.rbManualNumbers)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.cboOnlinePhonebook)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.cboOfflinePhonebook)
        Me.GroupBox1.Controls.Add(Me.NuManualSendCount)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Location = New System.Drawing.Point(9, 6)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(235, 141)
        Me.GroupBox1.TabIndex = 24
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Phone Numbers"
        '
        'txtAreaCode
        '
        Me.txtAreaCode.Location = New System.Drawing.Point(85, 31)
        Me.txtAreaCode.Name = "txtAreaCode"
        Me.txtAreaCode.Size = New System.Drawing.Size(41, 20)
        Me.txtAreaCode.TabIndex = 31
        Me.txtAreaCode.Text = "0098"
        '
        'rbOnlinePhoneBook
        '
        Me.rbOnlinePhoneBook.AutoSize = True
        Me.rbOnlinePhoneBook.Enabled = False
        Me.rbOnlinePhoneBook.Location = New System.Drawing.Point(10, 109)
        Me.rbOnlinePhoneBook.Name = "rbOnlinePhoneBook"
        Me.rbOnlinePhoneBook.Size = New System.Drawing.Size(14, 13)
        Me.rbOnlinePhoneBook.TabIndex = 26
        Me.rbOnlinePhoneBook.UseVisualStyleBackColor = True
        '
        'rbOfflinePhoneBook
        '
        Me.rbOfflinePhoneBook.AutoSize = True
        Me.rbOfflinePhoneBook.Location = New System.Drawing.Point(10, 82)
        Me.rbOfflinePhoneBook.Name = "rbOfflinePhoneBook"
        Me.rbOfflinePhoneBook.Size = New System.Drawing.Size(14, 13)
        Me.rbOfflinePhoneBook.TabIndex = 25
        Me.rbOfflinePhoneBook.UseVisualStyleBackColor = True
        '
        'rbManualNumbers
        '
        Me.rbManualNumbers.AutoSize = True
        Me.rbManualNumbers.Checked = True
        Me.rbManualNumbers.Location = New System.Drawing.Point(10, 34)
        Me.rbManualNumbers.Name = "rbManualNumbers"
        Me.rbManualNumbers.Size = New System.Drawing.Size(14, 13)
        Me.rbManualNumbers.TabIndex = 24
        Me.rbManualNumbers.TabStop = True
        Me.rbManualNumbers.UseVisualStyleBackColor = True
        '
        'cboOnlinePhonebook
        '
        Me.cboOnlinePhonebook.Enabled = False
        Me.cboOnlinePhonebook.FormattingEnabled = True
        Me.cboOnlinePhonebook.Location = New System.Drawing.Point(129, 106)
        Me.cboOnlinePhonebook.Name = "cboOnlinePhonebook"
        Me.cboOnlinePhonebook.Size = New System.Drawing.Size(97, 21)
        Me.cboOnlinePhonebook.TabIndex = 23
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(30, 109)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(101, 13)
        Me.Label9.TabIndex = 22
        Me.Label9.Text = "Online Phonebook :"
        '
        'cboOfflinePhonebook
        '
        Me.cboOfflinePhonebook.FormattingEnabled = True
        Me.cboOfflinePhonebook.Location = New System.Drawing.Point(129, 79)
        Me.cboOfflinePhonebook.Name = "cboOfflinePhonebook"
        Me.cboOfflinePhonebook.Size = New System.Drawing.Size(97, 21)
        Me.cboOfflinePhonebook.TabIndex = 21
        '
        'NuManualSendCount
        '
        Me.NuManualSendCount.Location = New System.Drawing.Point(85, 57)
        Me.NuManualSendCount.Maximum = New Decimal(New Integer() {50000, 0, 0, 0})
        Me.NuManualSendCount.Name = "NuManualSendCount"
        Me.NuManualSendCount.Size = New System.Drawing.Size(41, 20)
        Me.NuManualSendCount.TabIndex = 18
        Me.NuManualSendCount.Value = New Decimal(New Integer() {500, 0, 0, 0})
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(30, 82)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(101, 13)
        Me.Label8.TabIndex = 20
        Me.Label8.Text = "Offline Phonebook :"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(44, 59)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(35, 13)
        Me.Label3.TabIndex = 19
        Me.Label3.Text = "Count"
        '
        'tabPhoneBook
        '
        Me.tabPhoneBook.BackColor = System.Drawing.Color.MediumPurple
        Me.tabPhoneBook.Controls.Add(Me.lstPhone)
        Me.tabPhoneBook.Controls.Add(Me.btnDelPhonebook)
        Me.tabPhoneBook.Controls.Add(Me.btnEditPhonebook)
        Me.tabPhoneBook.Controls.Add(Me.btnAddPhonebook)
        Me.tabPhoneBook.Controls.Add(Me.Label7)
        Me.tabPhoneBook.Controls.Add(Me.txtPhonebookName)
        Me.tabPhoneBook.Controls.Add(Me.btnDel)
        Me.tabPhoneBook.Controls.Add(Me.btnEdit)
        Me.tabPhoneBook.Controls.Add(Me.btnAdd)
        Me.tabPhoneBook.Controls.Add(Me.Label6)
        Me.tabPhoneBook.Controls.Add(Me.txtPhoneNumber)
        Me.tabPhoneBook.Controls.Add(Me.cboPhoneBook)
        Me.tabPhoneBook.Controls.Add(Me.Label5)
        Me.tabPhoneBook.Location = New System.Drawing.Point(4, 22)
        Me.tabPhoneBook.Name = "tabPhoneBook"
        Me.tabPhoneBook.Padding = New System.Windows.Forms.Padding(3)
        Me.tabPhoneBook.Size = New System.Drawing.Size(253, 480)
        Me.tabPhoneBook.TabIndex = 1
        Me.tabPhoneBook.Text = "Offline Phonebook"
        '
        'lstPhone
        '
        Me.lstPhone.FormattingEnabled = True
        Me.lstPhone.Location = New System.Drawing.Point(9, 100)
        Me.lstPhone.Name = "lstPhone"
        Me.lstPhone.Size = New System.Drawing.Size(238, 303)
        Me.lstPhone.TabIndex = 13
        '
        'btnDelPhonebook
        '
        Me.btnDelPhonebook.Location = New System.Drawing.Point(169, 71)
        Me.btnDelPhonebook.Name = "btnDelPhonebook"
        Me.btnDelPhonebook.Size = New System.Drawing.Size(72, 23)
        Me.btnDelPhonebook.TabIndex = 12
        Me.btnDelPhonebook.Text = "Delete"
        Me.btnDelPhonebook.UseVisualStyleBackColor = True
        '
        'btnEditPhonebook
        '
        Me.btnEditPhonebook.Location = New System.Drawing.Point(91, 71)
        Me.btnEditPhonebook.Name = "btnEditPhonebook"
        Me.btnEditPhonebook.Size = New System.Drawing.Size(72, 23)
        Me.btnEditPhonebook.TabIndex = 11
        Me.btnEditPhonebook.Text = "Edit"
        Me.btnEditPhonebook.UseVisualStyleBackColor = True
        '
        'btnAddPhonebook
        '
        Me.btnAddPhonebook.Location = New System.Drawing.Point(13, 71)
        Me.btnAddPhonebook.Name = "btnAddPhonebook"
        Me.btnAddPhonebook.Size = New System.Drawing.Size(72, 23)
        Me.btnAddPhonebook.TabIndex = 10
        Me.btnAddPhonebook.Text = "Add"
        Me.btnAddPhonebook.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(6, 45)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(99, 13)
        Me.Label7.TabIndex = 9
        Me.Label7.Text = "Phonebook Name :"
        '
        'txtPhonebookName
        '
        Me.txtPhonebookName.Location = New System.Drawing.Point(111, 42)
        Me.txtPhonebookName.Name = "txtPhonebookName"
        Me.txtPhonebookName.Size = New System.Drawing.Size(136, 20)
        Me.txtPhonebookName.TabIndex = 8
        '
        'btnDel
        '
        Me.btnDel.Location = New System.Drawing.Point(169, 444)
        Me.btnDel.Name = "btnDel"
        Me.btnDel.Size = New System.Drawing.Size(72, 23)
        Me.btnDel.TabIndex = 7
        Me.btnDel.Text = "Delete"
        Me.btnDel.UseVisualStyleBackColor = True
        '
        'btnEdit
        '
        Me.btnEdit.Location = New System.Drawing.Point(91, 444)
        Me.btnEdit.Name = "btnEdit"
        Me.btnEdit.Size = New System.Drawing.Size(72, 23)
        Me.btnEdit.TabIndex = 6
        Me.btnEdit.Text = "Edit"
        Me.btnEdit.UseVisualStyleBackColor = True
        '
        'btnAdd
        '
        Me.btnAdd.Location = New System.Drawing.Point(13, 444)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(72, 23)
        Me.btnAdd.TabIndex = 5
        Me.btnAdd.Text = "Add"
        Me.btnAdd.UseVisualStyleBackColor = True
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(6, 418)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(84, 13)
        Me.Label6.TabIndex = 4
        Me.Label6.Text = "Phone Number :"
        '
        'txtPhoneNumber
        '
        Me.txtPhoneNumber.Location = New System.Drawing.Point(96, 415)
        Me.txtPhoneNumber.Name = "txtPhoneNumber"
        Me.txtPhoneNumber.Size = New System.Drawing.Size(151, 20)
        Me.txtPhoneNumber.TabIndex = 3
        '
        'cboPhoneBook
        '
        Me.cboPhoneBook.FormattingEnabled = True
        Me.cboPhoneBook.Location = New System.Drawing.Point(80, 15)
        Me.cboPhoneBook.Name = "cboPhoneBook"
        Me.cboPhoneBook.Size = New System.Drawing.Size(167, 21)
        Me.cboPhoneBook.TabIndex = 1
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(6, 18)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(68, 13)
        Me.Label5.TabIndex = 0
        Me.Label5.Text = "Phonebook :"
        '
        'tabSetting
        '
        Me.tabSetting.BackColor = System.Drawing.Color.MediumPurple
        Me.tabSetting.Controls.Add(Me.btnViberFileLocation)
        Me.tabSetting.Controls.Add(Me.Label24)
        Me.tabSetting.Controls.Add(Me.GroupBox4)
        Me.tabSetting.Controls.Add(Me.GroupBox3)
        Me.tabSetting.Controls.Add(Me.Label10)
        Me.tabSetting.Controls.Add(Me.Label2)
        Me.tabSetting.Controls.Add(Me.lblLastSentTime)
        Me.tabSetting.Controls.Add(Me.nuSleepTime)
        Me.tabSetting.Location = New System.Drawing.Point(4, 22)
        Me.tabSetting.Name = "tabSetting"
        Me.tabSetting.Size = New System.Drawing.Size(253, 480)
        Me.tabSetting.TabIndex = 2
        Me.tabSetting.Text = "Settings"
        '
        'btnViberFileLocation
        '
        Me.btnViberFileLocation.Location = New System.Drawing.Point(9, 436)
        Me.btnViberFileLocation.Name = "btnViberFileLocation"
        Me.btnViberFileLocation.Size = New System.Drawing.Size(233, 23)
        Me.btnViberFileLocation.TabIndex = 25
        Me.btnViberFileLocation.Text = "Set Viber File Location"
        Me.btnViberFileLocation.UseVisualStyleBackColor = True
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(19, 52)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(84, 13)
        Me.Label24.TabIndex = 21
        Me.Label24.Text = "Last Sent Time :"
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.btnSaveLocations)
        Me.GroupBox4.Controls.Add(Me.GroupBox10)
        Me.GroupBox4.Controls.Add(Me.GroupBox9)
        Me.GroupBox4.Controls.Add(Me.GroupBox7)
        Me.GroupBox4.Controls.Add(Me.GroupBox6)
        Me.GroupBox4.Controls.Add(Me.GroupBox8)
        Me.GroupBox4.Controls.Add(Me.GroupBox5)
        Me.GroupBox4.Location = New System.Drawing.Point(9, 125)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(233, 305)
        Me.GroupBox4.TabIndex = 20
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Viber Button Location"
        '
        'btnSaveLocations
        '
        Me.btnSaveLocations.Location = New System.Drawing.Point(9, 275)
        Me.btnSaveLocations.Name = "btnSaveLocations"
        Me.btnSaveLocations.Size = New System.Drawing.Size(214, 23)
        Me.btnSaveLocations.TabIndex = 24
        Me.btnSaveLocations.Text = "Save Locations"
        Me.btnSaveLocations.UseVisualStyleBackColor = True
        '
        'GroupBox10
        '
        Me.GroupBox10.Controls.Add(Me.NuFreePlaceY)
        Me.GroupBox10.Controls.Add(Me.Label22)
        Me.GroupBox10.Controls.Add(Me.NuFreePlaceX)
        Me.GroupBox10.Controls.Add(Me.Label23)
        Me.GroupBox10.Location = New System.Drawing.Point(9, 226)
        Me.GroupBox10.Name = "GroupBox10"
        Me.GroupBox10.Size = New System.Drawing.Size(214, 43)
        Me.GroupBox10.TabIndex = 23
        Me.GroupBox10.TabStop = False
        Me.GroupBox10.Text = "Free Place"
        '
        'NuFreePlaceY
        '
        Me.NuFreePlaceY.Location = New System.Drawing.Point(133, 14)
        Me.NuFreePlaceY.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NuFreePlaceY.Name = "NuFreePlaceY"
        Me.NuFreePlaceY.Size = New System.Drawing.Size(47, 20)
        Me.NuFreePlaceY.TabIndex = 18
        Me.NuFreePlaceY.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(11, 18)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(20, 13)
        Me.Label22.TabIndex = 3
        Me.Label22.Text = "X :"
        '
        'NuFreePlaceX
        '
        Me.NuFreePlaceX.Location = New System.Drawing.Point(37, 16)
        Me.NuFreePlaceX.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NuFreePlaceX.Name = "NuFreePlaceX"
        Me.NuFreePlaceX.Size = New System.Drawing.Size(47, 20)
        Me.NuFreePlaceX.TabIndex = 17
        Me.NuFreePlaceX.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(107, 16)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(20, 13)
        Me.Label23.TabIndex = 4
        Me.Label23.Text = "Y :"
        '
        'GroupBox9
        '
        Me.GroupBox9.Controls.Add(Me.NuSendPhotoIconY)
        Me.GroupBox9.Controls.Add(Me.Label20)
        Me.GroupBox9.Controls.Add(Me.NuSendPhotoIconX)
        Me.GroupBox9.Controls.Add(Me.Label21)
        Me.GroupBox9.Location = New System.Drawing.Point(9, 184)
        Me.GroupBox9.Name = "GroupBox9"
        Me.GroupBox9.Size = New System.Drawing.Size(214, 43)
        Me.GroupBox9.TabIndex = 22
        Me.GroupBox9.TabStop = False
        Me.GroupBox9.Text = "Send Photo Icon"
        '
        'NuSendPhotoIconY
        '
        Me.NuSendPhotoIconY.Location = New System.Drawing.Point(133, 14)
        Me.NuSendPhotoIconY.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NuSendPhotoIconY.Name = "NuSendPhotoIconY"
        Me.NuSendPhotoIconY.Size = New System.Drawing.Size(47, 20)
        Me.NuSendPhotoIconY.TabIndex = 18
        Me.NuSendPhotoIconY.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(11, 18)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(20, 13)
        Me.Label20.TabIndex = 3
        Me.Label20.Text = "X :"
        '
        'NuSendPhotoIconX
        '
        Me.NuSendPhotoIconX.Location = New System.Drawing.Point(37, 16)
        Me.NuSendPhotoIconX.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NuSendPhotoIconX.Name = "NuSendPhotoIconX"
        Me.NuSendPhotoIconX.Size = New System.Drawing.Size(47, 20)
        Me.NuSendPhotoIconX.TabIndex = 17
        Me.NuSendPhotoIconX.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(107, 16)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(20, 13)
        Me.Label21.TabIndex = 4
        Me.Label21.Text = "Y :"
        '
        'GroupBox7
        '
        Me.GroupBox7.Controls.Add(Me.NuMessageLocationY)
        Me.GroupBox7.Controls.Add(Me.Label16)
        Me.GroupBox7.Controls.Add(Me.NuMessageLocationX)
        Me.GroupBox7.Controls.Add(Me.Label17)
        Me.GroupBox7.Location = New System.Drawing.Point(9, 142)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(214, 43)
        Me.GroupBox7.TabIndex = 21
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "Message Location"
        '
        'NuMessageLocationY
        '
        Me.NuMessageLocationY.Location = New System.Drawing.Point(133, 14)
        Me.NuMessageLocationY.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NuMessageLocationY.Name = "NuMessageLocationY"
        Me.NuMessageLocationY.Size = New System.Drawing.Size(47, 20)
        Me.NuMessageLocationY.TabIndex = 18
        Me.NuMessageLocationY.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(11, 18)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(20, 13)
        Me.Label16.TabIndex = 3
        Me.Label16.Text = "X :"
        '
        'NuMessageLocationX
        '
        Me.NuMessageLocationX.Location = New System.Drawing.Point(37, 16)
        Me.NuMessageLocationX.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NuMessageLocationX.Name = "NuMessageLocationX"
        Me.NuMessageLocationX.Size = New System.Drawing.Size(47, 20)
        Me.NuMessageLocationX.TabIndex = 17
        Me.NuMessageLocationX.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(107, 16)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(20, 13)
        Me.Label17.TabIndex = 4
        Me.Label17.Text = "Y :"
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.NuPhoneNumberBoxY)
        Me.GroupBox6.Controls.Add(Me.Label1)
        Me.GroupBox6.Controls.Add(Me.NuPhoneNumberBoxX)
        Me.GroupBox6.Controls.Add(Me.Label15)
        Me.GroupBox6.Location = New System.Drawing.Point(9, 58)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(214, 43)
        Me.GroupBox6.TabIndex = 19
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Phone Number Box"
        '
        'NuPhoneNumberBoxY
        '
        Me.NuPhoneNumberBoxY.Location = New System.Drawing.Point(133, 14)
        Me.NuPhoneNumberBoxY.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NuPhoneNumberBoxY.Name = "NuPhoneNumberBoxY"
        Me.NuPhoneNumberBoxY.Size = New System.Drawing.Size(47, 20)
        Me.NuPhoneNumberBoxY.TabIndex = 18
        Me.NuPhoneNumberBoxY.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(11, 18)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(20, 13)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "X :"
        '
        'NuPhoneNumberBoxX
        '
        Me.NuPhoneNumberBoxX.Location = New System.Drawing.Point(37, 16)
        Me.NuPhoneNumberBoxX.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NuPhoneNumberBoxX.Name = "NuPhoneNumberBoxX"
        Me.NuPhoneNumberBoxX.Size = New System.Drawing.Size(47, 20)
        Me.NuPhoneNumberBoxX.TabIndex = 17
        Me.NuPhoneNumberBoxX.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(107, 16)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(20, 13)
        Me.Label15.TabIndex = 4
        Me.Label15.Text = "Y :"
        '
        'GroupBox8
        '
        Me.GroupBox8.Controls.Add(Me.NuSendTextMessageIconY)
        Me.GroupBox8.Controls.Add(Me.Label18)
        Me.GroupBox8.Controls.Add(Me.NuSendTextMessageIconX)
        Me.GroupBox8.Controls.Add(Me.Label19)
        Me.GroupBox8.Location = New System.Drawing.Point(9, 100)
        Me.GroupBox8.Name = "GroupBox8"
        Me.GroupBox8.Size = New System.Drawing.Size(214, 43)
        Me.GroupBox8.TabIndex = 20
        Me.GroupBox8.TabStop = False
        Me.GroupBox8.Text = "Send Text Message Icon"
        '
        'NuSendTextMessageIconY
        '
        Me.NuSendTextMessageIconY.Location = New System.Drawing.Point(133, 14)
        Me.NuSendTextMessageIconY.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NuSendTextMessageIconY.Name = "NuSendTextMessageIconY"
        Me.NuSendTextMessageIconY.Size = New System.Drawing.Size(47, 20)
        Me.NuSendTextMessageIconY.TabIndex = 18
        Me.NuSendTextMessageIconY.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(11, 18)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(20, 13)
        Me.Label18.TabIndex = 3
        Me.Label18.Text = "X :"
        '
        'NuSendTextMessageIconX
        '
        Me.NuSendTextMessageIconX.Location = New System.Drawing.Point(37, 16)
        Me.NuSendTextMessageIconX.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NuSendTextMessageIconX.Name = "NuSendTextMessageIconX"
        Me.NuSendTextMessageIconX.Size = New System.Drawing.Size(47, 20)
        Me.NuSendTextMessageIconX.TabIndex = 17
        Me.NuSendTextMessageIconX.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(107, 16)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(20, 13)
        Me.Label19.TabIndex = 4
        Me.Label19.Text = "Y :"
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.NuCallIconY)
        Me.GroupBox5.Controls.Add(Me.Label14)
        Me.GroupBox5.Controls.Add(Me.NuCallIconX)
        Me.GroupBox5.Controls.Add(Me.Label13)
        Me.GroupBox5.Location = New System.Drawing.Point(9, 16)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(214, 43)
        Me.GroupBox5.TabIndex = 18
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Call Icon"
        '
        'NuCallIconY
        '
        Me.NuCallIconY.Location = New System.Drawing.Point(133, 14)
        Me.NuCallIconY.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NuCallIconY.Name = "NuCallIconY"
        Me.NuCallIconY.Size = New System.Drawing.Size(47, 20)
        Me.NuCallIconY.TabIndex = 18
        Me.NuCallIconY.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(11, 18)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(20, 13)
        Me.Label14.TabIndex = 3
        Me.Label14.Text = "X :"
        '
        'NuCallIconX
        '
        Me.NuCallIconX.Location = New System.Drawing.Point(37, 16)
        Me.NuCallIconX.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NuCallIconX.Name = "NuCallIconX"
        Me.NuCallIconX.Size = New System.Drawing.Size(47, 20)
        Me.NuCallIconX.TabIndex = 17
        Me.NuCallIconX.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(107, 16)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(20, 13)
        Me.Label13.TabIndex = 4
        Me.Label13.Text = "Y :"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.lblMouseY)
        Me.GroupBox3.Controls.Add(Me.Label12)
        Me.GroupBox3.Controls.Add(Me.Label11)
        Me.GroupBox3.Controls.Add(Me.lblMouseX)
        Me.GroupBox3.Location = New System.Drawing.Point(9, 69)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(233, 50)
        Me.GroupBox3.TabIndex = 19
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Mouse Location"
        '
        'lblMouseY
        '
        Me.lblMouseY.AutoSize = True
        Me.lblMouseY.Location = New System.Drawing.Point(204, 22)
        Me.lblMouseY.Name = "lblMouseY"
        Me.lblMouseY.Size = New System.Drawing.Size(19, 13)
        Me.lblMouseY.TabIndex = 5
        Me.lblMouseY.Text = "----"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(143, 22)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(55, 13)
        Me.Label12.TabIndex = 4
        Me.Label12.Text = "Mouse Y :"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(19, 22)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(55, 13)
        Me.Label11.TabIndex = 3
        Me.Label11.Text = "Mouse X :"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(198, 20)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(44, 13)
        Me.Label10.TabIndex = 18
        Me.Label10.Text = "Minutes"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(4, 20)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(137, 13)
        Me.Label2.TabIndex = 17
        Me.Label2.Text = "Every 100 Message Sleep :"
        '
        'nuSleepTime
        '
        Me.nuSleepTime.Increment = New Decimal(New Integer() {5, 0, 0, 0})
        Me.nuSleepTime.Location = New System.Drawing.Point(147, 18)
        Me.nuSleepTime.Minimum = New Decimal(New Integer() {5, 0, 0, 0})
        Me.nuSleepTime.Name = "nuSleepTime"
        Me.nuSleepTime.Size = New System.Drawing.Size(47, 20)
        Me.nuSleepTime.TabIndex = 16
        Me.nuSleepTime.Value = New Decimal(New Integer() {15, 0, 0, 0})
        '
        'tabLicence
        '
        Me.tabLicence.BackColor = System.Drawing.Color.MediumPurple
        Me.tabLicence.Controls.Add(Me.PictureBox1)
        Me.tabLicence.Controls.Add(Me.GroupBox11)
        Me.tabLicence.Controls.Add(Me.DetailsLayoutPanel)
        Me.tabLicence.Controls.Add(Me.ApplicationTitle)
        Me.tabLicence.Location = New System.Drawing.Point(4, 22)
        Me.tabLicence.Name = "tabLicence"
        Me.tabLicence.Size = New System.Drawing.Size(253, 480)
        Me.tabLicence.TabIndex = 3
        Me.tabLicence.Text = "Licence"
        '
        'PictureBox1
        '
        Me.PictureBox1.BackgroundImage = Global.Viber_Bulk_Message_Sender.My.Resources.Resources.viber4windows
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox1.Location = New System.Drawing.Point(8, 265)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(236, 212)
        Me.PictureBox1.TabIndex = 16
        Me.PictureBox1.TabStop = False
        '
        'GroupBox11
        '
        Me.GroupBox11.Controls.Add(Me.Label30)
        Me.GroupBox11.Controls.Add(Me.Label27)
        Me.GroupBox11.Controls.Add(Me.lblLicenceExpireDate)
        Me.GroupBox11.Controls.Add(Me.Label28)
        Me.GroupBox11.Controls.Add(Me.lblLicenceStartDate)
        Me.GroupBox11.Controls.Add(Me.Label29)
        Me.GroupBox11.Controls.Add(Me.lblLicencetype)
        Me.GroupBox11.Controls.Add(Me.lblLicenceowner)
        Me.GroupBox11.Location = New System.Drawing.Point(8, 141)
        Me.GroupBox11.Name = "GroupBox11"
        Me.GroupBox11.Size = New System.Drawing.Size(236, 118)
        Me.GroupBox11.TabIndex = 15
        Me.GroupBox11.TabStop = False
        Me.GroupBox11.Text = "Licence"
        '
        'Label30
        '
        Me.Label30.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label30.BackColor = System.Drawing.Color.Transparent
        Me.Label30.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.Location = New System.Drawing.Point(15, 24)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(54, 21)
        Me.Label30.TabIndex = 9
        Me.Label30.Text = "Owner :"
        '
        'Label27
        '
        Me.Label27.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label27.BackColor = System.Drawing.Color.Transparent
        Me.Label27.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.Location = New System.Drawing.Point(15, 45)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(41, 21)
        Me.Label27.TabIndex = 6
        Me.Label27.Text = "Type :"
        '
        'lblLicenceExpireDate
        '
        Me.lblLicenceExpireDate.AutoSize = True
        Me.lblLicenceExpireDate.Location = New System.Drawing.Point(100, 89)
        Me.lblLicenceExpireDate.Name = "lblLicenceExpireDate"
        Me.lblLicenceExpireDate.Size = New System.Drawing.Size(45, 13)
        Me.lblLicenceExpireDate.TabIndex = 13
        Me.lblLicenceExpireDate.Text = "Licence"
        '
        'Label28
        '
        Me.Label28.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label28.BackColor = System.Drawing.Color.Transparent
        Me.Label28.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.Location = New System.Drawing.Point(15, 66)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(67, 21)
        Me.Label28.TabIndex = 7
        Me.Label28.Text = "Start Date :"
        '
        'lblLicenceStartDate
        '
        Me.lblLicenceStartDate.AutoSize = True
        Me.lblLicenceStartDate.Location = New System.Drawing.Point(88, 68)
        Me.lblLicenceStartDate.Name = "lblLicenceStartDate"
        Me.lblLicenceStartDate.Size = New System.Drawing.Size(45, 13)
        Me.lblLicenceStartDate.TabIndex = 12
        Me.lblLicenceStartDate.Text = "Licence"
        '
        'Label29
        '
        Me.Label29.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label29.BackColor = System.Drawing.Color.Transparent
        Me.Label29.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.Location = New System.Drawing.Point(15, 87)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(79, 21)
        Me.Label29.TabIndex = 8
        Me.Label29.Text = "Expire Date :"
        '
        'lblLicencetype
        '
        Me.lblLicencetype.AutoSize = True
        Me.lblLicencetype.Location = New System.Drawing.Point(62, 47)
        Me.lblLicencetype.Name = "lblLicencetype"
        Me.lblLicencetype.Size = New System.Drawing.Size(45, 13)
        Me.lblLicencetype.TabIndex = 11
        Me.lblLicencetype.Text = "Licence"
        '
        'lblLicenceowner
        '
        Me.lblLicenceowner.AutoSize = True
        Me.lblLicenceowner.Location = New System.Drawing.Point(75, 26)
        Me.lblLicenceowner.Name = "lblLicenceowner"
        Me.lblLicenceowner.Size = New System.Drawing.Size(45, 13)
        Me.lblLicenceowner.TabIndex = 10
        Me.lblLicenceowner.Text = "Licence"
        '
        'DetailsLayoutPanel
        '
        Me.DetailsLayoutPanel.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.DetailsLayoutPanel.BackColor = System.Drawing.Color.Transparent
        Me.DetailsLayoutPanel.ColumnCount = 1
        Me.DetailsLayoutPanel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 247.0!))
        Me.DetailsLayoutPanel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 142.0!))
        Me.DetailsLayoutPanel.Controls.Add(Me.Label25, 0, 2)
        Me.DetailsLayoutPanel.Controls.Add(Me.Version, 0, 0)
        Me.DetailsLayoutPanel.Controls.Add(Me.Copyright, 0, 1)
        Me.DetailsLayoutPanel.Location = New System.Drawing.Point(14, 61)
        Me.DetailsLayoutPanel.Name = "DetailsLayoutPanel"
        Me.DetailsLayoutPanel.RowCount = 3
        Me.DetailsLayoutPanel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 48.73949!))
        Me.DetailsLayoutPanel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 51.26051!))
        Me.DetailsLayoutPanel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.DetailsLayoutPanel.Size = New System.Drawing.Size(236, 74)
        Me.DetailsLayoutPanel.TabIndex = 4
        '
        'Label25
        '
        Me.Label25.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label25.BackColor = System.Drawing.Color.Transparent
        Me.Label25.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.Location = New System.Drawing.Point(3, 53)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(241, 21)
        Me.Label25.TabIndex = 3
        Me.Label25.Text = "Email : Info@Viber20.com"
        '
        'Version
        '
        Me.Version.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Version.BackColor = System.Drawing.Color.Transparent
        Me.Version.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Version.Location = New System.Drawing.Point(3, 3)
        Me.Version.Name = "Version"
        Me.Version.Size = New System.Drawing.Size(241, 20)
        Me.Version.TabIndex = 1
        Me.Version.Text = "Version {0}.{1:00}"
        '
        'Copyright
        '
        Me.Copyright.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Copyright.BackColor = System.Drawing.Color.Transparent
        Me.Copyright.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Copyright.Location = New System.Drawing.Point(3, 26)
        Me.Copyright.Name = "Copyright"
        Me.Copyright.Size = New System.Drawing.Size(241, 27)
        Me.Copyright.TabIndex = 2
        Me.Copyright.Text = "Copyright"
        '
        'ApplicationTitle
        '
        Me.ApplicationTitle.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.ApplicationTitle.BackColor = System.Drawing.Color.Transparent
        Me.ApplicationTitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ApplicationTitle.Location = New System.Drawing.Point(9, 16)
        Me.ApplicationTitle.Name = "ApplicationTitle"
        Me.ApplicationTitle.Size = New System.Drawing.Size(241, 35)
        Me.ApplicationTitle.TabIndex = 3
        Me.ApplicationTitle.Text = "Application Title"
        Me.ApplicationTitle.TextAlign = System.Drawing.ContentAlignment.BottomLeft
        '
        'TimerImageCount
        '
        Me.TimerImageCount.Interval = 10000
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'txtPishShomare
        '
        Me.txtPishShomare.Location = New System.Drawing.Point(132, 31)
        Me.txtPishShomare.Name = "txtPishShomare"
        Me.txtPishShomare.Size = New System.Drawing.Size(29, 20)
        Me.txtPishShomare.TabIndex = 32
        Me.txtPishShomare.Text = "912"
        '
        'txtNumber
        '
        Me.txtNumber.Location = New System.Drawing.Point(167, 31)
        Me.txtNumber.Name = "txtNumber"
        Me.txtNumber.Size = New System.Drawing.Size(62, 20)
        Me.txtNumber.TabIndex = 33
        '
        'Viber
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.MediumPurple
        Me.ClientSize = New System.Drawing.Size(280, 523)
        Me.Controls.Add(Me.TabControl1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Viber"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Viber"
        Me.TransparencyKey = System.Drawing.SystemColors.ActiveCaption
        Me.TabControl1.ResumeLayout(False)
        Me.tabBulk.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.NuManualSendCount, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tabPhoneBook.ResumeLayout(False)
        Me.tabPhoneBook.PerformLayout()
        Me.tabSetting.ResumeLayout(False)
        Me.tabSetting.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox10.ResumeLayout(False)
        Me.GroupBox10.PerformLayout()
        CType(Me.NuFreePlaceY, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NuFreePlaceX, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox9.ResumeLayout(False)
        Me.GroupBox9.PerformLayout()
        CType(Me.NuSendPhotoIconY, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NuSendPhotoIconX, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox7.ResumeLayout(False)
        Me.GroupBox7.PerformLayout()
        CType(Me.NuMessageLocationY, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NuMessageLocationX, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        CType(Me.NuPhoneNumberBoxY, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NuPhoneNumberBoxX, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox8.ResumeLayout(False)
        Me.GroupBox8.PerformLayout()
        CType(Me.NuSendTextMessageIconY, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NuSendTextMessageIconX, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        CType(Me.NuCallIconY, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NuCallIconX, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        CType(Me.nuSleepTime, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tabLicence.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox11.ResumeLayout(False)
        Me.GroupBox11.PerformLayout()
        Me.DetailsLayoutPanel.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents lblMouseX As System.Windows.Forms.Label
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents txtMessage As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents lblLastSentTime As System.Windows.Forms.Label
    Friend WithEvents btnOpenImagePlace As System.Windows.Forms.Button
    Friend WithEvents btnAutosending As System.Windows.Forms.Button
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents tabBulk As System.Windows.Forms.TabPage
    Friend WithEvents tabPhoneBook As System.Windows.Forms.TabPage
    Friend WithEvents cboPhoneBook As System.Windows.Forms.ComboBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents tabSetting As System.Windows.Forms.TabPage
    Friend WithEvents btnDel As System.Windows.Forms.Button
    Friend WithEvents btnEdit As System.Windows.Forms.Button
    Friend WithEvents btnAdd As System.Windows.Forms.Button
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtPhoneNumber As System.Windows.Forms.TextBox
    Friend WithEvents btnDelPhonebook As System.Windows.Forms.Button
    Friend WithEvents btnEditPhonebook As System.Windows.Forms.Button
    Friend WithEvents btnAddPhonebook As System.Windows.Forms.Button
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txtPhonebookName As System.Windows.Forms.TextBox
    Friend WithEvents tabLicence As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents cboOnlinePhonebook As System.Windows.Forms.ComboBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents cboOfflinePhonebook As System.Windows.Forms.ComboBox
    Friend WithEvents NuManualSendCount As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents nuSleepTime As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents lblMouseY As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents NuCallIconX As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents NuCallIconY As System.Windows.Forms.NumericUpDown
    Friend WithEvents GroupBox9 As System.Windows.Forms.GroupBox
    Friend WithEvents NuSendPhotoIconY As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents NuSendPhotoIconX As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents GroupBox7 As System.Windows.Forms.GroupBox
    Friend WithEvents NuMessageLocationY As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents NuMessageLocationX As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents NuPhoneNumberBoxY As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents NuPhoneNumberBoxX As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents GroupBox8 As System.Windows.Forms.GroupBox
    Friend WithEvents NuSendTextMessageIconY As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents NuSendTextMessageIconX As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents GroupBox10 As System.Windows.Forms.GroupBox
    Friend WithEvents NuFreePlaceY As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents NuFreePlaceX As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents btnSaveLocations As System.Windows.Forms.Button
    Friend WithEvents rbOnlinePhoneBook As System.Windows.Forms.RadioButton
    Friend WithEvents rbOfflinePhoneBook As System.Windows.Forms.RadioButton
    Friend WithEvents rbManualNumbers As System.Windows.Forms.RadioButton
    Friend WithEvents btnStopSending As System.Windows.Forms.Button
    Friend WithEvents DetailsLayoutPanel As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Version As System.Windows.Forms.Label
    Friend WithEvents Copyright As System.Windows.Forms.Label
    Friend WithEvents ApplicationTitle As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents lstPhone As System.Windows.Forms.ListBox
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents lblLicenceExpireDate As System.Windows.Forms.Label
    Friend WithEvents lblLicenceStartDate As System.Windows.Forms.Label
    Friend WithEvents lblLicencetype As System.Windows.Forms.Label
    Friend WithEvents lblLicenceowner As System.Windows.Forms.Label
    Friend WithEvents TimerImageCount As System.Windows.Forms.Timer
    Friend WithEvents btnViberFileLocation As System.Windows.Forms.Button
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents GroupBox11 As System.Windows.Forms.GroupBox
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents txtAreaCode As System.Windows.Forms.TextBox
    Friend WithEvents txtNumber As System.Windows.Forms.TextBox
    Friend WithEvents txtPishShomare As System.Windows.Forms.TextBox
End Class
