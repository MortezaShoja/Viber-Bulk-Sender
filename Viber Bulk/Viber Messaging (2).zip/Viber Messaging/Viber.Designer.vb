﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Viber
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Viber))
        Me.btnStart = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.txtMessage = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.ProgressBar1 = New System.Windows.Forms.ProgressBar()
        Me.txtPishShomare2 = New System.Windows.Forms.TextBox()
        Me.txtPishShomare = New System.Windows.Forms.TextBox()
        Me.txtToNumber = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtFromNumber = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.lblLastSentTime = New System.Windows.Forms.Label()
        Me.btnOpenImagePlace = New System.Windows.Forms.Button()
        Me.btnAutosending = New System.Windows.Forms.Button()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.tabBulk = New System.Windows.Forms.TabPage()
        Me.tabPhoneBook = New System.Windows.Forms.TabPage()
        Me.btnDelPhonebook = New System.Windows.Forms.Button()
        Me.btnEditPhonebook = New System.Windows.Forms.Button()
        Me.btnAddPhonebook = New System.Windows.Forms.Button()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtPhonebookName = New System.Windows.Forms.TextBox()
        Me.btnDel = New System.Windows.Forms.Button()
        Me.btnEdit = New System.Windows.Forms.Button()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtPhoneNumber = New System.Windows.Forms.TextBox()
        Me.chkPhone = New System.Windows.Forms.CheckedListBox()
        Me.cboPhoneBook = New System.Windows.Forms.ComboBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.tabSetting = New System.Windows.Forms.TabPage()
        Me.tabHelp = New System.Windows.Forms.TabPage()
        Me.TabControl1.SuspendLayout()
        Me.tabBulk.SuspendLayout()
        Me.tabPhoneBook.SuspendLayout()
        Me.tabSetting.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnStart
        '
        Me.btnStart.Location = New System.Drawing.Point(7, 405)
        Me.btnStart.Name = "btnStart"
        Me.btnStart.Size = New System.Drawing.Size(216, 23)
        Me.btnStart.TabIndex = 1
        Me.btnStart.Text = "Start Manual Sending"
        Me.btnStart.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(25, 379)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(19, 13)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "----"
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        '
        'txtMessage
        '
        Me.txtMessage.Location = New System.Drawing.Point(7, 26)
        Me.txtMessage.Multiline = True
        Me.txtMessage.Name = "txtMessage"
        Me.txtMessage.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtMessage.Size = New System.Drawing.Size(216, 196)
        Me.txtMessage.TabIndex = 4
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(53, 3)
        Me.Label2.Name = "Label2"
        Me.Label2.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.Label2.Size = New System.Drawing.Size(120, 20)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Message Text"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ProgressBar1
        '
        Me.ProgressBar1.Location = New System.Drawing.Point(7, 376)
        Me.ProgressBar1.Maximum = 500
        Me.ProgressBar1.Name = "ProgressBar1"
        Me.ProgressBar1.Size = New System.Drawing.Size(216, 23)
        Me.ProgressBar1.TabIndex = 6
        '
        'txtPishShomare2
        '
        Me.txtPishShomare2.Location = New System.Drawing.Point(85, 350)
        Me.txtPishShomare2.Name = "txtPishShomare2"
        Me.txtPishShomare2.ReadOnly = True
        Me.txtPishShomare2.Size = New System.Drawing.Size(50, 20)
        Me.txtPishShomare2.TabIndex = 14
        Me.txtPishShomare2.Text = "0912"
        '
        'txtPishShomare
        '
        Me.txtPishShomare.Location = New System.Drawing.Point(85, 324)
        Me.txtPishShomare.Name = "txtPishShomare"
        Me.txtPishShomare.Size = New System.Drawing.Size(50, 20)
        Me.txtPishShomare.TabIndex = 13
        Me.txtPishShomare.Text = "0912"
        '
        'txtToNumber
        '
        Me.txtToNumber.Location = New System.Drawing.Point(141, 350)
        Me.txtToNumber.Name = "txtToNumber"
        Me.txtToNumber.Size = New System.Drawing.Size(82, 20)
        Me.txtToNumber.TabIndex = 12
        Me.txtToNumber.Text = "0"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(13, 353)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(66, 13)
        Me.Label3.TabIndex = 11
        Me.Label3.Text = "To Number :"
        '
        'txtFromNumber
        '
        Me.txtFromNumber.Location = New System.Drawing.Point(141, 324)
        Me.txtFromNumber.Name = "txtFromNumber"
        Me.txtFromNumber.Size = New System.Drawing.Size(82, 20)
        Me.txtFromNumber.TabIndex = 10
        Me.txtFromNumber.Text = "0"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(6, 327)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(76, 13)
        Me.Label4.TabIndex = 9
        Me.Label4.Text = "From Number :"
        '
        'lblLastSentTime
        '
        Me.lblLastSentTime.AutoSize = True
        Me.lblLastSentTime.Location = New System.Drawing.Point(14, 424)
        Me.lblLastSentTime.Name = "lblLastSentTime"
        Me.lblLastSentTime.Size = New System.Drawing.Size(89, 13)
        Me.lblLastSentTime.TabIndex = 15
        Me.lblLastSentTime.Text = "آخرین زمان ارسال"
        Me.lblLastSentTime.Visible = False
        '
        'btnOpenImagePlace
        '
        Me.btnOpenImagePlace.Location = New System.Drawing.Point(7, 295)
        Me.btnOpenImagePlace.Name = "btnOpenImagePlace"
        Me.btnOpenImagePlace.Size = New System.Drawing.Size(216, 23)
        Me.btnOpenImagePlace.TabIndex = 16
        Me.btnOpenImagePlace.Text = "Open Pictures"
        Me.btnOpenImagePlace.UseVisualStyleBackColor = True
        '
        'btnAutosending
        '
        Me.btnAutosending.Location = New System.Drawing.Point(7, 434)
        Me.btnAutosending.Name = "btnAutosending"
        Me.btnAutosending.Size = New System.Drawing.Size(216, 23)
        Me.btnAutosending.TabIndex = 17
        Me.btnAutosending.Text = "Start Auto Sending"
        Me.btnAutosending.UseVisualStyleBackColor = True
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.tabBulk)
        Me.TabControl1.Controls.Add(Me.tabPhoneBook)
        Me.TabControl1.Controls.Add(Me.tabSetting)
        Me.TabControl1.Controls.Add(Me.tabHelp)
        Me.TabControl1.Location = New System.Drawing.Point(12, 12)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(240, 488)
        Me.TabControl1.TabIndex = 18
        '
        'tabBulk
        '
        Me.tabBulk.Controls.Add(Me.Label2)
        Me.tabBulk.Controls.Add(Me.btnAutosending)
        Me.tabBulk.Controls.Add(Me.txtMessage)
        Me.tabBulk.Controls.Add(Me.btnOpenImagePlace)
        Me.tabBulk.Controls.Add(Me.txtPishShomare2)
        Me.tabBulk.Controls.Add(Me.txtPishShomare)
        Me.tabBulk.Controls.Add(Me.btnStart)
        Me.tabBulk.Controls.Add(Me.txtToNumber)
        Me.tabBulk.Controls.Add(Me.ProgressBar1)
        Me.tabBulk.Controls.Add(Me.Label3)
        Me.tabBulk.Controls.Add(Me.Label4)
        Me.tabBulk.Controls.Add(Me.txtFromNumber)
        Me.tabBulk.Location = New System.Drawing.Point(4, 22)
        Me.tabBulk.Name = "tabBulk"
        Me.tabBulk.Padding = New System.Windows.Forms.Padding(3)
        Me.tabBulk.Size = New System.Drawing.Size(232, 462)
        Me.tabBulk.TabIndex = 0
        Me.tabBulk.Text = "Send Bulk"
        Me.tabBulk.UseVisualStyleBackColor = True
        '
        'tabPhoneBook
        '
        Me.tabPhoneBook.Controls.Add(Me.btnDelPhonebook)
        Me.tabPhoneBook.Controls.Add(Me.btnEditPhonebook)
        Me.tabPhoneBook.Controls.Add(Me.btnAddPhonebook)
        Me.tabPhoneBook.Controls.Add(Me.Label7)
        Me.tabPhoneBook.Controls.Add(Me.txtPhonebookName)
        Me.tabPhoneBook.Controls.Add(Me.btnDel)
        Me.tabPhoneBook.Controls.Add(Me.btnEdit)
        Me.tabPhoneBook.Controls.Add(Me.btnAdd)
        Me.tabPhoneBook.Controls.Add(Me.Label6)
        Me.tabPhoneBook.Controls.Add(Me.txtPhoneNumber)
        Me.tabPhoneBook.Controls.Add(Me.chkPhone)
        Me.tabPhoneBook.Controls.Add(Me.cboPhoneBook)
        Me.tabPhoneBook.Controls.Add(Me.Label5)
        Me.tabPhoneBook.Location = New System.Drawing.Point(4, 22)
        Me.tabPhoneBook.Name = "tabPhoneBook"
        Me.tabPhoneBook.Padding = New System.Windows.Forms.Padding(3)
        Me.tabPhoneBook.Size = New System.Drawing.Size(232, 462)
        Me.tabPhoneBook.TabIndex = 1
        Me.tabPhoneBook.Text = "Phonebook"
        Me.tabPhoneBook.UseVisualStyleBackColor = True
        '
        'btnDelPhonebook
        '
        Me.btnDelPhonebook.Location = New System.Drawing.Point(151, 71)
        Me.btnDelPhonebook.Name = "btnDelPhonebook"
        Me.btnDelPhonebook.Size = New System.Drawing.Size(65, 23)
        Me.btnDelPhonebook.TabIndex = 12
        Me.btnDelPhonebook.Text = "Delete"
        Me.btnDelPhonebook.UseVisualStyleBackColor = True
        '
        'btnEditPhonebook
        '
        Me.btnEditPhonebook.Location = New System.Drawing.Point(80, 71)
        Me.btnEditPhonebook.Name = "btnEditPhonebook"
        Me.btnEditPhonebook.Size = New System.Drawing.Size(65, 23)
        Me.btnEditPhonebook.TabIndex = 11
        Me.btnEditPhonebook.Text = "Edit"
        Me.btnEditPhonebook.UseVisualStyleBackColor = True
        '
        'btnAddPhonebook
        '
        Me.btnAddPhonebook.Location = New System.Drawing.Point(9, 71)
        Me.btnAddPhonebook.Name = "btnAddPhonebook"
        Me.btnAddPhonebook.Size = New System.Drawing.Size(65, 23)
        Me.btnAddPhonebook.TabIndex = 10
        Me.btnAddPhonebook.Text = "Add"
        Me.btnAddPhonebook.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(6, 45)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(99, 13)
        Me.Label7.TabIndex = 9
        Me.Label7.Text = "Phonebook Name :"
        '
        'txtPhonebookName
        '
        Me.txtPhonebookName.Location = New System.Drawing.Point(111, 42)
        Me.txtPhonebookName.Name = "txtPhonebookName"
        Me.txtPhonebookName.Size = New System.Drawing.Size(115, 20)
        Me.txtPhonebookName.TabIndex = 8
        '
        'btnDel
        '
        Me.btnDel.Location = New System.Drawing.Point(151, 433)
        Me.btnDel.Name = "btnDel"
        Me.btnDel.Size = New System.Drawing.Size(65, 23)
        Me.btnDel.TabIndex = 7
        Me.btnDel.Text = "Delete"
        Me.btnDel.UseVisualStyleBackColor = True
        '
        'btnEdit
        '
        Me.btnEdit.Location = New System.Drawing.Point(80, 433)
        Me.btnEdit.Name = "btnEdit"
        Me.btnEdit.Size = New System.Drawing.Size(65, 23)
        Me.btnEdit.TabIndex = 6
        Me.btnEdit.Text = "Edit"
        Me.btnEdit.UseVisualStyleBackColor = True
        '
        'btnAdd
        '
        Me.btnAdd.Location = New System.Drawing.Point(9, 433)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(65, 23)
        Me.btnAdd.TabIndex = 5
        Me.btnAdd.Text = "Add"
        Me.btnAdd.UseVisualStyleBackColor = True
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(6, 407)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(84, 13)
        Me.Label6.TabIndex = 4
        Me.Label6.Text = "Phone Number :"
        '
        'txtPhoneNumber
        '
        Me.txtPhoneNumber.Location = New System.Drawing.Point(96, 404)
        Me.txtPhoneNumber.Name = "txtPhoneNumber"
        Me.txtPhoneNumber.Size = New System.Drawing.Size(130, 20)
        Me.txtPhoneNumber.TabIndex = 3
        '
        'chkPhone
        '
        Me.chkPhone.FormattingEnabled = True
        Me.chkPhone.Location = New System.Drawing.Point(6, 102)
        Me.chkPhone.Name = "chkPhone"
        Me.chkPhone.Size = New System.Drawing.Size(220, 289)
        Me.chkPhone.TabIndex = 2
        '
        'cboPhoneBook
        '
        Me.cboPhoneBook.FormattingEnabled = True
        Me.cboPhoneBook.Location = New System.Drawing.Point(80, 15)
        Me.cboPhoneBook.Name = "cboPhoneBook"
        Me.cboPhoneBook.Size = New System.Drawing.Size(146, 21)
        Me.cboPhoneBook.TabIndex = 1
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(6, 18)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(68, 13)
        Me.Label5.TabIndex = 0
        Me.Label5.Text = "Phonebook :"
        '
        'tabSetting
        '
        Me.tabSetting.Controls.Add(Me.lblLastSentTime)
        Me.tabSetting.Controls.Add(Me.Label1)
        Me.tabSetting.Location = New System.Drawing.Point(4, 22)
        Me.tabSetting.Name = "tabSetting"
        Me.tabSetting.Size = New System.Drawing.Size(232, 462)
        Me.tabSetting.TabIndex = 2
        Me.tabSetting.Text = "Settings"
        Me.tabSetting.UseVisualStyleBackColor = True
        '
        'tabHelp
        '
        Me.tabHelp.Location = New System.Drawing.Point(4, 22)
        Me.tabHelp.Name = "tabHelp"
        Me.tabHelp.Size = New System.Drawing.Size(232, 462)
        Me.tabHelp.TabIndex = 3
        Me.tabHelp.Text = "Help"
        Me.tabHelp.UseVisualStyleBackColor = True
        '
        'Viber
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(262, 509)
        Me.Controls.Add(Me.TabControl1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Viber"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Viber"
        Me.TransparencyKey = System.Drawing.SystemColors.ActiveCaption
        Me.TabControl1.ResumeLayout(False)
        Me.tabBulk.ResumeLayout(False)
        Me.tabBulk.PerformLayout()
        Me.tabPhoneBook.ResumeLayout(False)
        Me.tabPhoneBook.PerformLayout()
        Me.tabSetting.ResumeLayout(False)
        Me.tabSetting.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btnStart As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents txtMessage As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents ProgressBar1 As System.Windows.Forms.ProgressBar
    Friend WithEvents txtPishShomare2 As System.Windows.Forms.TextBox
    Friend WithEvents txtPishShomare As System.Windows.Forms.TextBox
    Friend WithEvents txtToNumber As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtFromNumber As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents lblLastSentTime As System.Windows.Forms.Label
    Friend WithEvents btnOpenImagePlace As System.Windows.Forms.Button
    Friend WithEvents btnAutosending As System.Windows.Forms.Button
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents tabBulk As System.Windows.Forms.TabPage
    Friend WithEvents tabPhoneBook As System.Windows.Forms.TabPage
    Friend WithEvents cboPhoneBook As System.Windows.Forms.ComboBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents tabSetting As System.Windows.Forms.TabPage
    Friend WithEvents chkPhone As System.Windows.Forms.CheckedListBox
    Friend WithEvents btnDel As System.Windows.Forms.Button
    Friend WithEvents btnEdit As System.Windows.Forms.Button
    Friend WithEvents btnAdd As System.Windows.Forms.Button
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtPhoneNumber As System.Windows.Forms.TextBox
    Friend WithEvents btnDelPhonebook As System.Windows.Forms.Button
    Friend WithEvents btnEditPhonebook As System.Windows.Forms.Button
    Friend WithEvents btnAddPhonebook As System.Windows.Forms.Button
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txtPhonebookName As System.Windows.Forms.TextBox
    Friend WithEvents tabHelp As System.Windows.Forms.TabPage
End Class
